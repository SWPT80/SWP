package Homestay.Homestay_Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomestayManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
