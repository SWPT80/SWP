"use client"

import { useState, useCallback } from "react"

// Simple toast implementation
let toastId = 0

export function useToast() {
  const [toasts, setToasts] = useState([])

  const toast = useCallback(({ title, description, variant = "default" }) => {
    const id = ++toastId
    const newToast = {
      id,
      title,
      description,
      variant,
    }

    setToasts((prev) => [...prev, newToast])

    // Auto remove toast after 3 seconds
    setTimeout(() => {
      setToasts((prev) => prev.filter((toast) => toast.id !== id))
    }, 3000)

    // Show browser notification as fallback
    if (title) {
      console.log(`Toast: ${title}${description ? ` - ${description}` : ""}`)

      // Simple alert for demonstration (you can replace with a proper toast UI)
      if (typeof window !== "undefined") {
        const toastElement = document.createElement("div")
        toastElement.style.cssText = `
          position: fixed;
          top: 20px;
          right: 20px;
          background: ${variant === "destructive" ? "#dc2626" : "#2563eb"};
          color: white;
          padding: 12px 16px;
          border-radius: 6px;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
          z-index: 1000;
          max-width: 300px;
          font-size: 14px;
          animation: slideIn 0.3s ease;
        `

        toastElement.innerHTML = `
          <div style="font-weight: 600; margin-bottom: 4px;">${title}</div>
          ${description ? `<div style="opacity: 0.9;">${description}</div>` : ""}
        `

        document.body.appendChild(toastElement)

        setTimeout(() => {
          toastElement.style.animation = "slideOut 0.3s ease"
          setTimeout(() => {
            document.body.removeChild(toastElement)
          }, 300)
        }, 3000)
      }
    }
  }, [])

  return { toast, toasts }
}

// Add CSS animations
if (typeof document !== "undefined") {
  const style = document.createElement("style")
  style.textContent = `
    @keyframes slideIn {
      from {
        transform: translateX(100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
    
    @keyframes slideOut {
      from {
        transform: translateX(0);
        opacity: 1;
      }
      to {
        transform: translateX(100%);
        opacity: 0;
      }
    }
  `
  document.head.appendChild(style)
}
