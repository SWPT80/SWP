const badgeVariants = {
  default: {
    border: "none",
    backgroundColor: "#2563eb",
    color: "white",
  },
  secondary: {
    border: "none",
    backgroundColor: "#f3f4f6",
    color: "#374151",
  },
  destructive: {
    border: "none",
    backgroundColor: "#dc2626",
    color: "white",
  },
  outline: {
    border: "1px solid #d1d5db",
    backgroundColor: "transparent",
    color: "#374151",
  },
  success: {
    border: "none",
    backgroundColor: "#dcfce7",
    color: "#16a34a",
  },
  warning: {
    border: "none",
    backgroundColor: "#fef3c7",
    color: "#f59e0b",
  },
}

function Badge({ className, variant = "default", children, ...props }) {
  const baseStyle = {
    display: "inline-flex",
    alignItems: "center",
    borderRadius: "9999px",
    padding: "2px 10px",
    fontSize: "12px",
    fontWeight: "600",
    transition: "colors 0.2s ease",
    ...badgeVariants[variant],
  }

  return (
    <div style={{ ...baseStyle, ...props.style }} {...props}>
      {children}
    </div>
  )
}

export { Badge, badgeVariants }
