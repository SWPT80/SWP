

import * as React from "react"
import * as ProgressPrimitive from "@radix-ui/react-progress"

const Progress = React.forwardRef(({ className, value, ...props }, ref) => (
  <ProgressPrimitive.Root
    ref={ref}
    style={{
      position: "relative",
      height: "8px",
      width: "100%",
      overflow: "hidden",
      borderRadius: "9999px",
      backgroundColor: "#e5e7eb",
      ...props.style,
    }}
    {...props}
  >
    <ProgressPrimitive.Indicator
      style={{
        height: "100%",
        width: "100%",
        flex: "1 1 0%",
        backgroundColor: "#3b82f6",
        transition: "all 0.3s ease",
        transform: `translateX(-${100 - (value || 0)}%)`,
      }}
    />
  </ProgressPrimitive.Root>
))
Progress.displayName = ProgressPrimitive.Root.displayName

export { Progress }
