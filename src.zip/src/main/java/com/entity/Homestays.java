package com.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Homestays")
public class Homestays {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "homestay_id")
    private Integer homestayId;

    @Column(name = "host_id")
    private Integer hostId;

    @Column(name = "homestaysName")
    private String homestaysName;

    @Column(name = "address")
    private String address;

    @Column(name = "description")
    private String description;

    @Column(name = "status")
    private Boolean status;

    // Getters, setters...

    public Integer getHomestayId() {
        return homestayId;
    }

    public void setHomestayId(Integer homestayId) {
        this.homestayId = homestayId;
    }

    public Integer getHostId() {
        return hostId;
    }

    public void setHostId(Integer hostId) {
        this.hostId = hostId;
    }

    public String getHomestaysName() {
        return homestaysName;
    }

    public void setHomestaysName(String homestaysName) {
        this.homestaysName = homestaysName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }
}
