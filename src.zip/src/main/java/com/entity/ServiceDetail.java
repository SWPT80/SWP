package com.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ServiceDetail")
public class ServiceDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "serviceDetail_id")
    private Integer serviceDetailId;

    @ManyToOne
    @JoinColumn(name = "type_id", referencedColumnName = "type_id")
    private ServiceType serviceType;

    @Column(name = "serviceName", length = 100)
    private String serviceName;

    @Column(name = "status")
    private Boolean status = true;


    @OneToMany(mappedBy = "serviceDetail", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<ServiceOption> serviceOptions = new ArrayList<>();

    // Getters & Setters

    public Integer getServiceDetailId() {
        return serviceDetailId;
    }

    public void setServiceDetailId(Integer serviceDetailId) {
        this.serviceDetailId = serviceDetailId;
    }

    public ServiceType getServiceType() {
        return serviceType;
    }

    public void setServiceType(ServiceType serviceType) {
        this.serviceType = serviceType;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public List<ServiceOption> getServiceOptions() {
        return serviceOptions;
    }

    public void setServiceOptions(List<ServiceOption> serviceOptions) {
        this.serviceOptions = serviceOptions;
    }
}

