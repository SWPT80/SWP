package com.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
@Table(name = "ServiceOption")
public class ServiceOption {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "option_id")
    private Integer optionId;

    @ManyToOne
    @JoinColumn(name = "serviceDetail_id", referencedColumnName = "serviceDetail_id")
    @JsonBackReference
    private ServiceDetail serviceDetail;

    @Column(name = "optionName", length = 100)
    private String optionName;

    @Column(name = "price", precision = 10, scale = 2)
    private BigDecimal price;

    @Column(name = "service_imageURL", columnDefinition = "varchar(max)")
    private String serviceImageURL;

    @Column(name = "status")
    private Boolean status = true;

    // Getters and Setters

    public Integer getOptionId() {
        return optionId;
    }

    public void setOptionId(Integer optionId) {
        this.optionId = optionId;
    }

    public ServiceDetail getServiceDetail() {
        return serviceDetail;
    }

    public void setServiceDetail(ServiceDetail serviceDetail) {
        this.serviceDetail = serviceDetail;
    }

    public String getOptionName() {
        return optionName;
    }

    public void setOptionName(String optionName) {
        this.optionName = optionName;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getServiceImageURL() {
        return serviceImageURL;
    }

    public void setServiceImageURL(String serviceImageURL) {
        this.serviceImageURL = serviceImageURL;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }
}

