package com.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import java.io.Serializable;

@Embeddable
public class BookingServiceKey implements Serializable {

    @Column(name = "booking_id")
    private Integer bookingId;

    @Column(name = "option_id")
    private Integer optionId;

    // Constructors, equals, and hashCode
}
