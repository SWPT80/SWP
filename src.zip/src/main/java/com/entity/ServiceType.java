package com.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "ServiceType")
public class ServiceType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "type_id")
    private Integer typeId;

    @Column(name = "typeName", length = 100)
    private String typeName;

    // Optional: one-to-many with ServiceDetail
    // Getters & Setters
}