package com.dto.response;


public class ConversationDTO {
    private int id;

    public ConversationDTO(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
