package com.respository;

import com.entity.BookingWithService;
import com.entity.BookingServiceKey;
import com.services.BookingService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingServiceRepository extends JpaRepository<BookingWithService, BookingServiceKey> {

    @Query("SELECT MONTH(b.createdAt), so.optionName, SUM(bs.quantity * so.price) " +
            "FROM BookingWithService bs " +
            "JOIN bs.booking b " +
            "JOIN bs.serviceOption so " +
            "WHERE b.status = 'completed' " +
            "GROUP BY MONTH(b.createdAt), so.optionName " +
            "ORDER BY MONTH(b.createdAt), so.optionName")
    List<Object[]> getMonthlyRevenueByService();

    @Query("SELECT MONTH(b.createdAt), SUM(bs.quantity * so.price) " +
            "FROM BookingWithService bs " +
            "JOIN bs.booking b " +
            "JOIN bs.serviceOption so " +
            "WHERE b.status = 'completed' " +
            "GROUP BY MONTH(b.createdAt) " +
            "ORDER BY MONTH(b.createdAt)")
    List<Object[]> getTotalServiceRevenuePerMonth();
    @Query("SELECT MONTH(b.createdAt), b.homestayId, so.optionName, SUM(bs.quantity * so.price) " +
            "FROM BookingWithService bs " +
            "JOIN bs.booking b " +
            "JOIN bs.serviceOption so " +
            "WHERE b.status = 'completed' " +
            "GROUP BY MONTH(b.createdAt), b.homestayId, so.optionName " +
            "ORDER BY MONTH(b.createdAt), b.homestayId, so.optionName")
    List<Object[]> getDetailedServiceRevenuePerMonth();
    @Query("SELECT MONTH(b.createdAt), b.homestayId, so.optionName, SUM(bs.quantity) " +
            "FROM BookingWithService bs " +
            "JOIN bs.booking b " +
            "JOIN bs.serviceOption so " +
            "WHERE b.status = 'completed' " +
            "GROUP BY MONTH(b.createdAt), b.homestayId, so.optionName " +
            "ORDER BY MONTH(b.createdAt), b.homestayId, so.optionName")
    List<Object[]> countServiceBookingsByMonthAndHomestayAndService();

}