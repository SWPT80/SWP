package com.respository;

import com.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer> {

    @Query("SELECT MONTH(b.createdAt), b.homestayId, SUM(b.totalAmount) " +
            "FROM Booking b " +
            "WHERE b.status = 'completed' " +
            "GROUP BY MONTH(b.createdAt), b.homestayId " +
            "ORDER BY MONTH(b.createdAt), b.homestayId")
    List<Object[]> getMonthlyRevenueByHomestay();

    @Query("SELECT MONTH(b.createdAt), b.homestayId, b.roomNumber, SUM(b.totalAmount) " +
            "FROM Booking b " +
            "WHERE b.status = 'completed' " +
            "GROUP BY MONTH(b.createdAt), b.homestayId, b.roomNumber " +
            "ORDER BY MONTH(b.createdAt), b.homestayId, b.roomNumber")
    List<Object[]> getMonthlyRevenueByRoomAndHomestay();

    @Query("SELECT MONTH(b.createdAt), b.homestayId, r.roomType, COUNT(b) " +
            "FROM Booking b JOIN Rooms r " +
            "ON b.homestayId = r.homestayId AND b.roomNumber = r.roomId " +
            "WHERE b.status = 'completed' " +
            "GROUP BY MONTH(b.createdAt), b.homestayId, r.roomType " +
            "ORDER BY MONTH(b.createdAt), b.homestayId, r.roomType")
    List<Object[]> countCompletedBookingsByRoomTypePerMonthPerHomestay();


}
