package com.controller;

import com.services.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/revenue/monthly")
    public ResponseEntity<?> getMonthlyRevenue() {
        return ResponseEntity.ok(reportService.getMonthlyRevenue());
    }

    @GetMapping("/revenue/room")
    public ResponseEntity<?> getRevenueByRoom() {
        return ResponseEntity.ok(reportService.getRevenueByRoom());
    }   

    @GetMapping("/revenue/service")
    public ResponseEntity<?> getRevenueByService() {
        return ResponseEntity.ok(reportService.getRevenueByEachService());
    }


    @GetMapping("/count/bookings")
    public ResponseEntity<?> getBookingCount() {
        return ResponseEntity.ok(reportService.getTotalCompletedBookings());
    }

    @GetMapping("/count/services")
    public ResponseEntity<?> getServiceBookingCount() {
        return ResponseEntity.ok(reportService.getTotalServiceBookings());
    }
}
