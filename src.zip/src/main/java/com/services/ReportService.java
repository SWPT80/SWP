package com.services;

import com.respository.BookingRepository;
import com.respository.BookingServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReportService {
    @Autowired
    private BookingRepository bookingRepo;
    @Autowired
    private BookingServiceRepository bookingServiceRepo;

    public List<Map<String, Object>> getMonthlyRevenue() {
        List<Object[]> rawData = bookingRepo.getMonthlyRevenueByHomestay();
        List<Map<String, Object>> result = new ArrayList<>();

        for (Object[] obj : rawData) {
            Map<String, Object> map = new HashMap<>();
            map.put("month", obj[0]);
            map.put("homestayId", obj[1]);
            map.put("totalRevenue", obj[2]);
            result.add(map);
        }

        return result;
    }

    public List<Map<String, Object>> getRevenueByRoom() {
        List<Object[]> rawData = bookingRepo.getMonthlyRevenueByRoomAndHomestay();
        List<Map<String, Object>> result = new ArrayList<>();

        for (Object[] obj : rawData) {
            Map<String, Object> map = new HashMap<>();
            map.put("month", obj[0]);
            map.put("homestayId", obj[1]);
            map.put("roomNumber", obj[2]);
            map.put("totalRevenue", obj[3]);
            result.add(map);
        }

        return result;
    }

    public List<Map<String, Object>> getTotalCompletedBookings() {
        List<Object[]> rawData = bookingRepo.countCompletedBookingsByRoomTypePerMonthPerHomestay();
        List<Map<String, Object>> result = new ArrayList<>();

        for (Object[] obj : rawData) {
            Map<String, Object> map = new HashMap<>();
            map.put("month", obj[0]);
            map.put("homestayId", obj[1]);
            map.put("roomType", obj[2]);
            map.put("bookingCount", obj[3]);
            result.add(map);
        }

        return result;
    }

    public List<Map<String, Object>> getRevenueByEachService() {
        List<Object[]> rawData = bookingServiceRepo.getDetailedServiceRevenuePerMonth();
        List<Map<String, Object>> result = new ArrayList<>();

        for (Object[] obj : rawData) {
            Map<String, Object> map = new HashMap<>();
            map.put("month", obj[0]);
            map.put("homestayId", obj[1]);
            map.put("serviceName", obj[2]);
            map.put("totalRevenue", obj[3]);
            result.add(map);
        }

        return result;
    }


    public List<Object[]> getRevenueByService() {
        return bookingServiceRepo.getMonthlyRevenueByService();
    }
    public List<Map<String, Object>> getTotalServiceBookings() {
        List<Object[]> rawData = bookingServiceRepo.countServiceBookingsByMonthAndHomestayAndService();
        List<Map<String, Object>> result = new ArrayList<>();

        for (Object[] obj : rawData) {
            Map<String, Object> map = new HashMap<>();
            map.put("month", obj[0]);
            map.put("homestayId", obj[1]);
            map.put("serviceName", obj[2]);
            map.put("bookingCount", obj[3]);
            result.add(map);
        }

        return result;
    }
}
