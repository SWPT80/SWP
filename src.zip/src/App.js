import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/HomePage';
import Home from './pages/Home';
import AuthForm from './components/LoginSignupForm';
import Experience from './pages/Experience';
import Service from './pages/Service';
import HomeLayout from './layouts/HomeLayout';
function App() {
  return (
    <Router>
      <Routes>
        {/* Các trang dùng HomeLayout */}
      <Route element={<HomeLayout />}>
          {/* Các route con sẽ render vào vị trí Outlet */}
          <Route path="/" element={<Home />} />
          <Route path="/experience" element={<Experience />} />
          <Route path="/service" element={<Service />} />
        </Route>

      {/* Các trang Admin và Host */}
        {/*
        <Route element={<AdminLayout />}>
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/special" element={<SpecialPage />} />
        </Route>

        <Route element={<HostLayout />}>
          <Route path="/host" element={<AdminPage />} />
          <Route path="/special" element={<SpecialPage />} />
        </Route>
        */}

      </Routes>
    </Router>
  );
}

export default App;