

import { useState, useEffect } from "react"
import {
  BarChart,
  ChevronLeft,
  ChevronRight,
  Search,
  Plus,
  Edit,
  Trash,
  ChevronDown,
  Bell,
  Home,
  CalendarIcon,
  MessageSquare,
  Star,
  Award,
  CreditCard,
  Utensils,
  Clock,
  DollarSign,
  Filter,
  Download,
  MoreHorizontal,
  Menu,
} from "lucide-react"
import { Progress } from "./components/ui/progress"
import { useToast } from "./components/ui/use-toast"
import {
  Bar,
  BarChart as RechartsBarChart,
  Line,
  LineChart as RechartsLineChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const styles = {
  container: {
    display: "flex",
    height: "100vh",
    backgroundColor: "#f3f4f6",
  },
  sidebar: {
    width: "256px",
    backgroundColor: "white",
    borderRight: "1px solid #e5e7eb",
    display: "flex",
    flexDirection: "column",
  },
  sidebarMobile: {
    position: "fixed",
    inset: "0",
    zIndex: "50",
    transform: "translateX(0)",
    transition: "transform 0.3s ease-in-out",
  },
  sidebarMobileHidden: {
    transform: "translateX(-100%)",
  },
  sidebarHeader: {
    padding: "24px",
    borderBottom: "1px solid #e5e7eb",
  },
  logo: {
    fontSize: "24px",
    fontWeight: "600",
    color: "#7c3aed",
  },
  nav: {
    flex: "1",
    paddingTop: "16px",
    paddingBottom: "16px",
    overflowY: "auto",
  },
  navList: {
    display: "flex",
    flexDirection: "column",
    gap: "4px",
    paddingLeft: "8px",
    paddingRight: "8px",
  },
  navButton: {
    display: "flex",
    alignItems: "center",
    width: "100%",
    padding: "12px 16px",
    fontSize: "14px",
    fontWeight: "500",
    borderRadius: "0 6px 6px 0",
    border: "none",
    backgroundColor: "transparent",
    cursor: "pointer",
    transition: "all 0.2s ease",
  },
  navButtonActive: {
    color: "#2563eb",
    backgroundColor: "#eff6ff",
    borderLeft: "4px solid #2563eb",
  },
  navButtonInactive: {
    color: "#6b7280",
    "&:hover": {
      backgroundColor: "#f9fafb",
      color: "#111827",
    },
  },
  navIcon: {
    marginRight: "12px",
    height: "20px",
    width: "20px",
  },
  mainContent: {
    flex: "1",
    display: "flex",
    flexDirection: "column",
    overflow: "hidden",
  },
  header: {
    backgroundColor: "white",
    borderBottom: "1px solid #e5e7eb",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "16px 24px",
  },
  headerTitle: {
    fontSize: "20px",
    fontWeight: "600",
    color: "#1f2937",
  },
  headerActions: {
    display: "flex",
    alignItems: "center",
    gap: "16px",
  },
  main: {
    flex: "1",
    overflowY: "auto",
    padding: "24px",
    backgroundColor: "#f9fafb",
  },
  statsGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
    gap: "24px",
    marginBottom: "24px",
  },
  statsCard: {
    backgroundColor: "white",
    borderRadius: "8px",
    padding: "16px",
    boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
    display: "flex",
    alignItems: "center",
  },
  statsIcon: {
    padding: "12px",
    borderRadius: "50%",
    marginRight: "16px",
  },
  statsIconBlue: {
    backgroundColor: "#eff6ff",
    color: "#2563eb",
  },
  statsIconAmber: {
    backgroundColor: "#fef3c7",
    color: "#f59e0b",
  },
  statsIconCyan: {
    backgroundColor: "#ecfeff",
    color: "#06b6d4",
  },
  statsNumber: {
    fontSize: "24px",
    fontWeight: "bold",
    marginRight: "8px",
  },
  statsLabel: {
    fontSize: "14px",
    color: "#6b7280",
    marginBottom: "8px",
  },
  statsChange: {
    fontSize: "12px",
    padding: "2px 6px",
    borderRadius: "4px",
    fontWeight: "500",
  },
  statsChangePositive: {
    backgroundColor: "#dcfce7",
    color: "#16a34a",
  },
  statsChangeNegative: {
    backgroundColor: "#fee2e2",
    color: "#dc2626",
  },
  chartsGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
    gap: "24px",
    marginBottom: "24px",
  },
  card: {
    backgroundColor: "white",
    borderRadius: "8px",
    boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
  },
  cardHeader: {
    padding: "16px",
    paddingBottom: "8px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },
  cardTitle: {
    fontSize: "16px",
    fontWeight: "500",
  },
  cardContent: {
    padding: "16px",
    paddingTop: "0",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
  },
  tableHeader: {
    borderBottom: "1px solid #e5e7eb",
  },
  tableHeaderCell: {
    padding: "12px",
    textAlign: "left",
    fontSize: "12px",
    fontWeight: "500",
    color: "#6b7280",
    textTransform: "uppercase",
  },
  tableRow: {
    borderBottom: "1px solid #f3f4f6",
  },
  tableCell: {
    padding: "12px",
    fontSize: "14px",
  },
  avatar: {
    width: "32px",
    height: "32px",
    borderRadius: "50%",
    marginRight: "12px",
  },
  badge: {
    padding: "4px 8px",
    borderRadius: "4px",
    fontSize: "12px",
    fontWeight: "500",
  },
  badgeSuccess: {
    backgroundColor: "#dcfce7",
    color: "#16a34a",
  },
  badgeWarning: {
    backgroundColor: "#fef3c7",
    color: "#f59e0b",
  },
  button: {
    padding: "8px 16px",
    borderRadius: "6px",
    border: "none",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "500",
    transition: "all 0.2s ease",
  },
  buttonPrimary: {
    backgroundColor: "#2563eb",
    color: "white",
    "&:hover": {
      backgroundColor: "#1d4ed8",
    },
  },
  buttonSecondary: {
    backgroundColor: "#f3f4f6",
    color: "#374151",
    "&:hover": {
      backgroundColor: "#e5e7eb",
    },
  },
  input: {
    padding: "8px 12px",
    border: "1px solid #d1d5db",
    borderRadius: "6px",
    fontSize: "14px",
    "&:focus": {
      outline: "none",
      borderColor: "#2563eb",
      boxShadow: "0 0 0 3px rgba(37, 99, 235, 0.1)",
    },
  },
  mobileToggle: {
    position: "fixed",
    bottom: "16px",
    right: "16px",
    zIndex: "50",
    borderRadius: "50%",
    height: "48px",
    width: "48px",
    boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
    backgroundColor: "white",
  },
}

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("stays")
  const [activeSection, setActiveSection] = useState("dashboard")
  const [isMobile, setIsMobile] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768)
    }

    handleResize()
    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  // Sample data for charts
  const revenueData = [
    { name: "Sun", value: 8 },
    { name: "Mon", value: 10 },
    { name: "Tue", value: 12 },
    { name: "Wed", value: 11 },
    { name: "Thu", value: 9 },
    { name: "Fri", value: 11 },
    { name: "Sat", value: 12 },
  ]

  const guestsData = [
    { name: "Sun", value: 8000 },
    { name: "Mon", value: 10000 },
    { name: "Tue", value: 12000 },
    { name: "Wed", value: 9000 },
    { name: "Thu", value: 6000 },
    { name: "Fri", value: 8000 },
  ]

  const roomsData = [
    { name: "Sun", occupied: 15, booked: 10, available: 25 },
    { name: "Mon", occupied: 20, booked: 12, available: 18 },
    { name: "Tue", occupied: 18, booked: 15, available: 17 },
    { name: "Wed", occupied: 22, booked: 10, available: 18 },
    { name: "Thu", occupied: 20, booked: 15, available: 15 },
    { name: "Fri", occupied: 18, booked: 12, available: 20 },
    { name: "Sat", occupied: 15, booked: 10, available: 25 },
  ]

  const foodOrdersData = [
    { name: "Breakfast", value: 35 },
    { name: "Lunch", value: 45 },
    { name: "Dinner", value: 55 },
    { name: "Room Service", value: 25 },
  ]

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"]

  const bookingData = [
    {
      id: 1,
      name: "Ram Kailash",
      phone: "9905598912",
      bookingId: "SDK89635",
      nights: 2,
      roomType: "1 King Room",
      guests: 2,
      paid: "rsp.150",
      cost: "rsp.1500",
      avatar: "/placeholder.svg?height=32&width=32",
    },
    {
      id: 2,
      name: "Samira Karki",
      phone: "9815394203",
      bookingId: "SDK89635",
      nights: 4,
      roomType: ["1 Queen", "1 King Room"],
      guests: 5,
      paid: "paid",
      cost: "rsp.5500",
      avatar: "/placeholder.svg?height=32&width=32",
    },
    {
      id: 3,
      name: "Jeevan Rai",
      phone: "9865328452",
      bookingId: "SDK89635",
      nights: 1,
      roomType: ["1 Deluxe", "1 King Room"],
      guests: 3,
      paid: "rsp.150",
      cost: "rsp.2500",
      avatar: "/placeholder.svg?height=32&width=32",
    },
    {
      id: 4,
      name: "Bindu Sharma",
      phone: "9845653124",
      bookingId: "SDK89635",
      nights: 3,
      roomType: ["1 Deluxe", "1 King Room"],
      guests: 2,
      paid: "rsp.150",
      cost: "rsp.3000",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  ]

  const foodOrders = [
    {
      id: "FO-1234",
      guest: "Ram Kailash",
      room: "101",
      items: ["Chicken Curry", "Naan Bread", "Rice"],
      total: "rsp.850",
      status: "Delivered",
      time: "12:30 PM",
    },
    {
      id: "FO-1235",
      guest: "Samira Karki",
      room: "205",
      items: ["Vegetable Pasta", "Garlic Bread", "Tiramisu"],
      total: "rsp.1200",
      status: "Preparing",
      time: "1:15 PM",
    },
    {
      id: "FO-1236",
      guest: "Jeevan Rai",
      room: "310",
      items: ["Club Sandwich", "French Fries", "Coke"],
      total: "rsp.650",
      status: "On the way",
      time: "1:45 PM",
    },
  ]

  const invoices = [
    {
      id: "INV-2023-001",
      guest: "Ram Kailash",
      date: "26 Jul 2023",
      amount: "rsp.1500",
      status: "Paid",
      items: [
        { description: "Room Charges (2 nights)", amount: "rsp.1200" },
        { description: "Food & Beverages", amount: "rsp.300" },
      ],
    },
    {
      id: "INV-2023-002",
      guest: "Samira Karki",
      date: "25 Jul 2023",
      amount: "rsp.5500",
      status: "Paid",
      items: [
        { description: "Room Charges (4 nights)", amount: "rsp.4800" },
        { description: "Food & Beverages", amount: "rsp.700" },
      ],
    },
    {
      id: "INV-2023-003",
      guest: "Jeevan Rai",
      date: "24 Jul 2023",
      amount: "rsp.2500",
      status: "Pending",
      items: [
        { description: "Room Charges (1 night)", amount: "rsp.2000" },
        { description: "Food & Beverages", amount: "rsp.500" },
      ],
    },
  ]

  const calendarEvents = [
    { date: 2, guest: "Carl Larson II", nights: 2, guests: 2 },
    { date: 9, guest: "Mrs. Emmett Morar", nights: 2, guests: 2 },
    { date: 24, guest: "Marjorie Klocko", nights: 2, guests: 2 },
  ]

  const renderDashboard = () => (
    <div>
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: "16px" }}>
        <p style={{ fontSize: "14px", color: "#6b7280" }}>Wed // July 26th, 2023</p>
      </div>

      {/* Stats Cards */}
      <div style={styles.statsGrid}>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconBlue }}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M5 12h14"></path>
              <path d="M12 5l7 7-7 7"></path>
            </svg>
          </div>
          <div>
            <p style={styles.statsLabel}>
              Arrival <span style={{ fontSize: "12px" }}>(This week)</span>
            </p>
            <div style={{ display: "flex", alignItems: "center" }}>
              <h3 style={{ ...styles.statsNumber, marginRight: "8px" }}>73</h3>
              <span style={{ ...styles.statsChange, ...styles.statsChangePositive }}>+24%</span>
            </div>
            <p style={{ fontSize: "12px", color: "#6b7280" }}>Previous week: 35</p>
          </div>
        </div>

        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconAmber }}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M19 12H5"></path>
              <path d="M12 19l-7-7 7-7"></path>
            </svg>
          </div>
          <div>
            <p style={styles.statsLabel}>
              Departure <span style={{ fontSize: "12px" }}>(This week)</span>
            </p>
            <div style={{ display: "flex", alignItems: "center" }}>
              <h3 style={{ ...styles.statsNumber, marginRight: "8px" }}>35</h3>
              <span style={{ ...styles.statsChange, ...styles.statsChangeNegative }}>-12%</span>
            </div>
            <p style={{ fontSize: "12px", color: "#6b7280" }}>Previous week: 97</p>
          </div>
        </div>

        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconCyan }}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="16" y1="2" x2="16" y2="6"></line>
              <line x1="8" y1="2" x2="8" y2="6"></line>
              <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
          </div>
          <div>
            <p style={styles.statsLabel}>
              Booking <span style={{ fontSize: "12px" }}>(This week)</span>
            </p>
            <div style={{ display: "flex", alignItems: "center" }}>
              <h3 style={{ ...styles.statsNumber, marginRight: "8px" }}>237</h3>
              <span style={{ ...styles.statsChange, ...styles.statsChangePositive }}>+31%</span>
            </div>
            <p style={{ fontSize: "12px", color: "#6b7280" }}>Previous week: 187</p>
          </div>
        </div>

        <div style={styles.statsCard}>
          <div>
            <p style={{ ...styles.statsLabel, marginBottom: "8px" }}>Today Activities</p>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
              <div style={{ textAlign: "center" }}>
                <div
                  style={{
                    backgroundColor: "#2563eb",
                    color: "white",
                    borderRadius: "50%",
                    width: "40px",
                    height: "40px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: "0 auto 4px",
                  }}
                >
                  <span>5</span>
                </div>
                <p style={{ fontSize: "12px" }}>
                  Room
                  <br />
                  Available
                </p>
              </div>
              <div style={{ textAlign: "center" }}>
                <div
                  style={{
                    backgroundColor: "#2563eb",
                    color: "white",
                    borderRadius: "50%",
                    width: "40px",
                    height: "40px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: "0 auto 4px",
                  }}
                >
                  <span>10</span>
                </div>
                <p style={{ fontSize: "12px" }}>
                  Room
                  <br />
                  Blocked
                </p>
              </div>
              <div style={{ textAlign: "center" }}>
                <div
                  style={{
                    backgroundColor: "#2563eb",
                    color: "white",
                    borderRadius: "50%",
                    width: "40px",
                    height: "40px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: "0 auto 4px",
                  }}
                >
                  <span>15</span>
                </div>
                <p style={{ fontSize: "12px" }}>Guest</p>
              </div>
            </div>
            <div style={{ marginTop: "16px" }}>
              <p style={{ fontSize: "12px", color: "#6b7280" }}>Total Revenue</p>
              <p style={{ fontSize: "18px", fontWeight: "bold" }}>Rs.35k</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div style={styles.chartsGrid}>
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <h3 style={styles.cardTitle}>Revenue</h3>
            <button style={{ ...styles.button, ...styles.buttonSecondary }}>
              this week <ChevronDown style={{ marginLeft: "4px", height: "12px", width: "12px" }} />
            </button>
          </div>
          <div style={styles.cardContent}>
            <div style={{ height: "200px", width: "100%" }}>
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart data={revenueData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} />
                  <YAxis hide={true} />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div
                            style={{
                              backgroundColor: "white",
                              padding: "8px",
                              border: "1px solid #e5e7eb",
                              borderRadius: "4px",
                              boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
                            }}
                          >
                            <p style={{ fontSize: "12px" }}>{`${payload[0].value} K`}</p>
                          </div>
                        )
                      }
                      return null
                    }}
                  />
                  <Bar dataKey="value" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                </RechartsBarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <h3 style={styles.cardTitle}>Guests</h3>
            <button style={{ ...styles.button, ...styles.buttonSecondary }}>
              this week <ChevronDown style={{ marginLeft: "4px", height: "12px", width: "12px" }} />
            </button>
          </div>
          <div style={styles.cardContent}>
            <div style={{ height: "200px", width: "100%" }}>
              <ResponsiveContainer width="100%" height="100%">
                <RechartsLineChart data={guestsData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} />
                  <YAxis hide={true} />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div
                            style={{
                              backgroundColor: "white",
                              padding: "8px",
                              border: "1px solid #e5e7eb",
                              borderRadius: "4px",
                              boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
                            }}
                          >
                            <p style={{ fontSize: "12px" }}>{`${payload[0].value}`}</p>
                          </div>
                        )
                      }
                      return null
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="#3B82F6"
                    strokeWidth={2}
                    dot={{ r: 4, fill: "white", stroke: "#3B82F6", strokeWidth: 2 }}
                    activeDot={{ r: 6 }}
                  />
                </RechartsLineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <h3 style={styles.cardTitle}>Rooms</h3>
            <button style={{ ...styles.button, ...styles.buttonSecondary }}>
              this week <ChevronDown style={{ marginLeft: "4px", height: "12px", width: "12px" }} />
            </button>
          </div>
          <div style={styles.cardContent}>
            <div style={{ fontSize: "12px", marginBottom: "8px" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <p>Total 50 Rooms</p>
                <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                    <span
                      style={{ height: "8px", width: "8px", borderRadius: "50%", backgroundColor: "#3b82f6" }}
                    ></span>
                    <span>Occupied</span>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                    <span
                      style={{ height: "8px", width: "8px", borderRadius: "50%", backgroundColor: "#10b981" }}
                    ></span>
                    <span>Booked</span>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                    <span
                      style={{ height: "8px", width: "8px", borderRadius: "50%", backgroundColor: "#f59e0b" }}
                    ></span>
                    <span>Available</span>
                  </div>
                </div>
              </div>
            </div>
            <div style={{ height: "180px", width: "100%" }}>
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart data={roomsData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} />
                  <YAxis hide={true} />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div
                            style={{
                              backgroundColor: "white",
                              padding: "8px",
                              border: "1px solid #e5e7eb",
                              borderRadius: "4px",
                              boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
                            }}
                          >
                            <p style={{ fontSize: "12px" }}>{`Occupied: ${payload[0].value}`}</p>
                            <p style={{ fontSize: "12px" }}>{`Booked: ${payload[1].value}`}</p>
                            <p style={{ fontSize: "12px" }}>{`Available: ${payload[2].value}`}</p>
                          </div>
                        )
                      }
                      return null
                    }}
                  />
                  <Bar dataKey="occupied" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="booked" fill="#10B981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="available" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                </RechartsBarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      {/* Booking Table */}
      <div style={{ ...styles.card, marginBottom: "24px" }}>
        <div style={styles.cardHeader}>
          <h3 style={styles.cardTitle}>
            Todays Booking{" "}
            <span style={{ fontSize: "12px", fontWeight: "normal", color: "#6b7280" }}>(8 Guest today)</span>
          </h3>
        </div>
        <div style={styles.cardContent}>
          <div style={{ marginBottom: "16px" }}>
            <div style={{ display: "flex", borderBottom: "1px solid #e5e7eb" }}>
              <button
                onClick={() => setActiveTab("stays")}
                style={{
                  padding: "8px 16px",
                  border: "none",
                  backgroundColor: "transparent",
                  borderBottom: activeTab === "stays" ? "2px solid #2563eb" : "2px solid transparent",
                  color: activeTab === "stays" ? "#2563eb" : "#6b7280",
                  cursor: "pointer",
                }}
              >
                Stays
              </button>
              <button
                onClick={() => setActiveTab("packages")}
                style={{
                  padding: "8px 16px",
                  border: "none",
                  backgroundColor: "transparent",
                  borderBottom: activeTab === "packages" ? "2px solid #2563eb" : "2px solid transparent",
                  color: activeTab === "packages" ? "#2563eb" : "#6b7280",
                  cursor: "pointer",
                }}
              >
                Packages
              </button>
              <button
                onClick={() => setActiveTab("arrivals")}
                style={{
                  padding: "8px 16px",
                  border: "none",
                  backgroundColor: "transparent",
                  borderBottom: activeTab === "arrivals" ? "2px solid #2563eb" : "2px solid transparent",
                  color: activeTab === "arrivals" ? "#2563eb" : "#6b7280",
                  cursor: "pointer",
                }}
              >
                Arrivals
              </button>
              <button
                onClick={() => setActiveTab("departure")}
                style={{
                  padding: "8px 16px",
                  border: "none",
                  backgroundColor: "transparent",
                  borderBottom: activeTab === "departure" ? "2px solid #2563eb" : "2px solid transparent",
                  color: activeTab === "departure" ? "#2563eb" : "#6b7280",
                  cursor: "pointer",
                }}
              >
                Departure
              </button>
            </div>
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: "16px",
              gap: "16px",
              flexWrap: "wrap",
            }}
          >
            <div style={{ position: "relative", flex: "1", minWidth: "300px" }}>
              <Search
                style={{
                  position: "absolute",
                  left: "12px",
                  top: "50%",
                  transform: "translateY(-50%)",
                  height: "16px",
                  width: "16px",
                  color: "#9ca3af",
                }}
              />
              <input
                type="text"
                placeholder="Search guest by name or phone number or booking ID"
                style={{
                  ...styles.input,
                  paddingLeft: "40px",
                  width: "100%",
                }}
              />
            </div>
            <button
              style={{ ...styles.button, ...styles.buttonPrimary, display: "flex", alignItems: "center", gap: "8px" }}
            >
              <Plus style={{ height: "16px", width: "16px" }} />
              Add Booking
            </button>
          </div>

          <div style={{ overflowX: "auto" }}>
            <table style={styles.table}>
              <thead style={styles.tableHeader}>
                <tr>
                  <th style={styles.tableHeaderCell}>
                    <div style={{ display: "flex", alignItems: "center" }}>
                      NAME <ChevronDown style={{ height: "16px", width: "16px", marginLeft: "4px" }} />
                    </div>
                  </th>
                  <th style={styles.tableHeaderCell}>BOOKING ID</th>
                  <th style={styles.tableHeaderCell}>NIGHTS</th>
                  <th style={styles.tableHeaderCell}>ROOM TYPE</th>
                  <th style={styles.tableHeaderCell}>GUESTS</th>
                  <th style={styles.tableHeaderCell}>PAID</th>
                  <th style={styles.tableHeaderCell}>COST</th>
                  <th style={styles.tableHeaderCell}>ACTION</th>
                </tr>
              </thead>
              <tbody>
                {bookingData.map((booking) => (
                  <tr key={booking.id} style={styles.tableRow}>
                    <td style={styles.tableCell}>
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <img src={booking.avatar || "/placeholder.svg"} alt={booking.name} style={styles.avatar} />
                        <div>
                          <p style={{ fontWeight: "500", margin: "0" }}>{booking.name}</p>
                          <p style={{ fontSize: "12px", color: "#6b7280", margin: "0" }}>{booking.phone}</p>
                        </div>
                      </div>
                    </td>
                    <td style={styles.tableCell}>{booking.bookingId}</td>
                    <td style={styles.tableCell}>{booking.nights}</td>
                    <td style={styles.tableCell}>
                      {Array.isArray(booking.roomType) ? (
                        <div>
                          {booking.roomType.map((type, index) => (
                            <p key={index} style={{ margin: "0" }}>
                              {type}
                            </p>
                          ))}
                        </div>
                      ) : (
                        booking.roomType
                      )}
                    </td>
                    <td style={styles.tableCell}>{booking.guests} Guests</td>
                    <td style={styles.tableCell}>
                      {booking.paid === "paid" ? (
                        <span style={{ ...styles.badge, ...styles.badgeSuccess }}>paid</span>
                      ) : (
                        booking.paid
                      )}
                    </td>
                    <td style={styles.tableCell}>{booking.cost}</td>
                    <td style={styles.tableCell}>
                      <div style={{ display: "flex", gap: "8px" }}>
                        <button style={{ ...styles.button, ...styles.buttonSecondary, padding: "4px 8px" }}>
                          <Edit style={{ height: "16px", width: "16px" }} />
                        </button>
                        <button style={{ ...styles.button, ...styles.buttonSecondary, padding: "4px 8px" }}>
                          <Trash style={{ height: "16px", width: "16px" }} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{ display: "flex", justifyContent: "flex-end", marginTop: "16px" }}>
            <button
              style={{
                ...styles.button,
                backgroundColor: "transparent",
                color: "#2563eb",
                textDecoration: "underline",
              }}
            >
              See other Bookings
            </button>
          </div>
        </div>
      </div>

      {/* Calendar and Rating */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(400px, 1fr))", gap: "24px" }}>
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <h3 style={styles.cardTitle}>Calendar</h3>
          </div>
          <div style={styles.cardContent}>
            <div
              style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "16px" }}
            >
              <button style={{ ...styles.button, ...styles.buttonSecondary, padding: "4px 8px" }}>
                <ChevronLeft style={{ height: "16px", width: "16px" }} />
              </button>
              <h3 style={{ fontSize: "14px", fontWeight: "500" }}>August 2023</h3>
              <button style={{ ...styles.button, ...styles.buttonSecondary, padding: "4px 8px" }}>
                <ChevronRight style={{ height: "16px", width: "16px" }} />
              </button>
            </div>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(7, 1fr)",
                gap: "4px",
                textAlign: "center",
                fontSize: "12px",
              }}
            >
              <div style={{ padding: "4px", fontWeight: "500" }}>SU</div>
              <div style={{ padding: "4px", fontWeight: "500" }}>MO</div>
              <div style={{ padding: "4px", fontWeight: "500" }}>TU</div>
              <div style={{ padding: "4px", fontWeight: "500" }}>WE</div>
              <div style={{ padding: "4px", fontWeight: "500" }}>TH</div>
              <div style={{ padding: "4px", fontWeight: "500" }}>FR</div>
              <div style={{ padding: "4px", fontWeight: "500" }}>SA</div>

              <div style={{ padding: "4px", color: "#9ca3af" }}>31</div>
              <div style={{ padding: "4px" }}>1</div>
              <div style={{ padding: "4px", position: "relative" }}>
                2
                <span
                  style={{
                    position: "absolute",
                    bottom: "0",
                    left: "50%",
                    transform: "translateX(-50%)",
                    width: "4px",
                    height: "4px",
                    backgroundColor: "#2563eb",
                    borderRadius: "50%",
                  }}
                ></span>
              </div>
              <div style={{ padding: "4px" }}>3</div>
              <div style={{ padding: "4px" }}>4</div>
              <div style={{ padding: "4px" }}>5</div>
              <div style={{ padding: "4px" }}>6</div>

              {/* Continue with more calendar days... */}
            </div>

            <div style={{ marginTop: "24px", border: "1px solid #e5e7eb", borderRadius: "6px", padding: "12px" }}>
              <h4 style={{ fontSize: "14px", fontWeight: "500", marginBottom: "8px" }}>
                August 02, 2023 Booking Lists
              </h4>
              <p style={{ fontSize: "12px", color: "#6b7280", marginBottom: "12px" }}>(3 Bookings)</p>

              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {calendarEvents.map((event, index) => (
                  <div key={index} style={{ display: "flex", alignItems: "center" }}>
                    <img src="/placeholder.svg?height=32&width=32" alt={event.guest} style={styles.avatar} />
                    <div>
                      <p style={{ fontSize: "14px", fontWeight: "500", margin: "0" }}>{event.guest}</p>
                      <p style={{ fontSize: "12px", color: "#6b7280", margin: "0" }}>
                        {event.nights} Nights | {event.guests} Guests
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <h3 style={styles.cardTitle}>Overall Rating</h3>
            <button style={{ ...styles.button, ...styles.buttonSecondary }}>
              This Week <ChevronDown style={{ marginLeft: "4px", height: "12px", width: "12px" }} />
            </button>
          </div>
          <div style={styles.cardContent}>
            <div style={{ display: "flex", justifyContent: "center", marginBottom: "24px" }}>
              <div style={{ position: "relative", width: "192px", height: "96px" }}>
                <svg viewBox="0 0 100 50" style={{ width: "100%", height: "100%" }}>
                  <path d="M 0 50 A 50 50 0 0 1 100 50" fill="none" stroke="#e5e7eb" strokeWidth="10" />
                  <path d="M 0 50 A 50 50 0 0 1 90 50" fill="none" stroke="#3b82f6" strokeWidth="10" />
                </svg>
                <div
                  style={{
                    position: "absolute",
                    inset: "0",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <div style={{ textAlign: "center" }}>
                    <p style={{ fontSize: "14px", fontWeight: "500" }}>Rating</p>
                    <p style={{ fontSize: "24px", fontWeight: "bold" }}>4.5/5</p>
                    <span style={{ ...styles.statsChange, ...styles.statsChangePositive }}>+31%</span>
                  </div>
                </div>
              </div>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: "14px" }}>Cleanliness</span>
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                  <Progress value={90} style={{ height: "8px", width: "128px" }} />
                  <span style={{ fontSize: "14px" }}>4.5</span>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: "14px" }}>Facilities</span>
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                  <Progress value={90} style={{ height: "8px", width: "128px" }} />
                  <span style={{ fontSize: "14px" }}>4.5</span>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: "14px" }}>Location</span>
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                  <Progress value={50} style={{ height: "8px", width: "128px" }} />
                  <span style={{ fontSize: "14px" }}>2.5</span>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: "14px" }}>Room Comfort</span>
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                  <Progress value={50} style={{ height: "8px", width: "128px" }} />
                  <span style={{ fontSize: "14px" }}>2.5</span>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: "14px" }}>Service</span>
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                  <Progress value={76} style={{ height: "8px", width: "128px" }} />
                  <span style={{ fontSize: "14px" }}>3.8</span>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: "14px" }}>Value for money</span>
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                  <Progress value={76} style={{ height: "8px", width: "128px" }} />
                  <span style={{ fontSize: "14px" }}>3.8</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  const renderCheckInOut = () => (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: "600" }}>Check In-Out Management</h2>
        <div style={{ display: "flex", gap: "8px" }}>
          <button
            style={{ ...styles.button, ...styles.buttonSecondary, display: "flex", alignItems: "center", gap: "4px" }}
          >
            <Filter style={{ height: "16px", width: "16px" }} />
            Filter
          </button>
          <button
            style={{ ...styles.button, ...styles.buttonPrimary, display: "flex", alignItems: "center", gap: "4px" }}
            onClick={() => {
              toast({
                title: "Quick Check-in",
                description: "Check-in form would open here",
              })
            }}
          >
            <Plus style={{ height: "16px", width: "16px" }} />
            Quick Check-in
          </button>
        </div>
      </div>

      <div style={styles.statsGrid}>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconBlue }}>
            <CalendarIcon style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Today's Check-ins</p>
            <h3 style={styles.statsNumber}>12</h3>
            <p style={{ fontSize: "12px", color: "#16a34a" }}>3 completed</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, backgroundColor: "#dcfce7", color: "#16a34a" }}>
            <Home style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Today's Check-outs</p>
            <h3 style={styles.statsNumber}>8</h3>
            <p style={{ fontSize: "12px", color: "#16a34a" }}>5 completed</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconAmber }}>
            <Clock style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Pending Actions</p>
            <h3 style={styles.statsNumber}>7</h3>
            <p style={{ fontSize: "12px", color: "#f59e0b" }}>Requires attention</p>
          </div>
        </div>
      </div>

      <div style={{ ...styles.card, marginBottom: "24px" }}>
        <div style={styles.cardHeader}>
          <h3 style={styles.cardTitle}>Today's Schedule</h3>
        </div>
        <div style={styles.cardContent}>
          <div style={{ overflowX: "auto" }}>
            <table style={styles.table}>
              <thead style={styles.tableHeader}>
                <tr>
                  <th style={styles.tableHeaderCell}>Guest Name</th>
                  <th style={styles.tableHeaderCell}>Room</th>
                  <th style={styles.tableHeaderCell}>Type</th>
                  <th style={styles.tableHeaderCell}>Time</th>
                  <th style={styles.tableHeaderCell}>Status</th>
                  <th style={styles.tableHeaderCell}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { name: "John Smith", room: "101", type: "Check-in", time: "2:00 PM", status: "Pending" },
                  { name: "Sarah Johnson", room: "205", type: "Check-out", time: "11:00 AM", status: "Completed" },
                  { name: "Mike Wilson", room: "310", type: "Check-in", time: "3:30 PM", status: "In Progress" },
                ].map((item, index) => (
                  <tr key={index} style={styles.tableRow}>
                    <td style={styles.tableCell}>{item.name}</td>
                    <td style={styles.tableCell}>{item.room}</td>
                    <td style={styles.tableCell}>{item.type}</td>
                    <td style={styles.tableCell}>{item.time}</td>
                    <td style={styles.tableCell}>
                      <span
                        style={{
                          ...styles.badge,
                          ...(item.status === "Completed"
                            ? styles.badgeSuccess
                            : item.status === "Pending"
                              ? styles.badgeWarning
                              : { backgroundColor: "#e5e7eb", color: "#374151" }),
                        }}
                      >
                        {item.status}
                      </span>
                    </td>
                    <td style={styles.tableCell}>
                      <button
                        style={{ ...styles.button, ...styles.buttonPrimary, padding: "4px 8px", fontSize: "12px" }}
                        onClick={() => {
                          toast({
                            title: `${item.type} Action`,
                            description: `Processing ${item.type.toLowerCase()} for ${item.name}`,
                          })
                        }}
                      >
                        {item.type === "Check-in" ? "Check In" : "Check Out"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )

  const renderRooms = () => (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: "600" }}>Room Management</h2>
        <div style={{ display: "flex", gap: "8px" }}>
          <button
            style={{ ...styles.button, ...styles.buttonSecondary, display: "flex", alignItems: "center", gap: "4px" }}
          >
            <Filter style={{ height: "16px", width: "16px" }} />
            Filter
          </button>
          <button
            style={{ ...styles.button, ...styles.buttonPrimary, display: "flex", alignItems: "center", gap: "4px" }}
            onClick={() => {
              toast({
                title: "Add Room",
                description: "Room creation form would open here",
              })
            }}
          >
            <Plus style={{ height: "16px", width: "16px" }} />
            Add Room
          </button>
        </div>
      </div>

      <div style={styles.statsGrid}>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconBlue }}>
            <Home style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Total Rooms</p>
            <h3 style={styles.statsNumber}>50</h3>
            <p style={{ fontSize: "12px", color: "#6b7280" }}>All room types</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, backgroundColor: "#dcfce7", color: "#16a34a" }}>
            <Home style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Available</p>
            <h3 style={styles.statsNumber}>18</h3>
            <p style={{ fontSize: "12px", color: "#16a34a" }}>Ready for booking</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconAmber }}>
            <Home style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Occupied</p>
            <h3 style={styles.statsNumber}>25</h3>
            <p style={{ fontSize: "12px", color: "#f59e0b" }}>Currently in use</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, backgroundColor: "#fee2e2", color: "#dc2626" }}>
            <Home style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Maintenance</p>
            <h3 style={styles.statsNumber}>7</h3>
            <p style={{ fontSize: "12px", color: "#dc2626" }}>Under repair</p>
          </div>
        </div>
      </div>

      <div style={{ ...styles.card, marginBottom: "24px" }}>
        <div style={styles.cardHeader}>
          <h3 style={styles.cardTitle}>Room List</h3>
        </div>
        <div style={styles.cardContent}>
          <div style={{ overflowX: "auto" }}>
            <table style={styles.table}>
              <thead style={styles.tableHeader}>
                <tr>
                  <th style={styles.tableHeaderCell}>Room Number</th>
                  <th style={styles.tableHeaderCell}>Type</th>
                  <th style={styles.tableHeaderCell}>Status</th>
                  <th style={styles.tableHeaderCell}>Guest</th>
                  <th style={styles.tableHeaderCell}>Rate</th>
                  <th style={styles.tableHeaderCell}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { number: "101", type: "Standard", status: "Occupied", guest: "John Smith", rate: "Rs.2,500" },
                  { number: "102", type: "Standard", status: "Available", guest: "-", rate: "Rs.2,500" },
                  { number: "201", type: "Deluxe", status: "Occupied", guest: "Sarah Johnson", rate: "Rs.3,500" },
                  { number: "202", type: "Deluxe", status: "Maintenance", guest: "-", rate: "Rs.3,500" },
                  { number: "301", type: "Suite", status: "Available", guest: "-", rate: "Rs.5,000" },
                ].map((room, index) => (
                  <tr key={index} style={styles.tableRow}>
                    <td style={{ ...styles.tableCell, fontWeight: "500" }}>{room.number}</td>
                    <td style={styles.tableCell}>{room.type}</td>
                    <td style={styles.tableCell}>
                      <span
                        style={{
                          ...styles.badge,
                          ...(room.status === "Available"
                            ? styles.badgeSuccess
                            : room.status === "Occupied"
                              ? styles.badgeWarning
                              : { backgroundColor: "#fee2e2", color: "#dc2626" }),
                        }}
                      >
                        {room.status}
                      </span>
                    </td>
                    <td style={styles.tableCell}>{room.guest}</td>
                    <td style={styles.tableCell}>{room.rate}</td>
                    <td style={styles.tableCell}>
                      <div style={{ display: "flex", gap: "4px" }}>
                        <button
                          style={{ ...styles.button, ...styles.buttonSecondary, padding: "4px 8px" }}
                          onClick={() => {
                            toast({
                              title: "Edit Room",
                              description: `Editing room ${room.number}`,
                            })
                          }}
                        >
                          <Edit style={{ height: "16px", width: "16px" }} />
                        </button>
                        <button
                          style={{ ...styles.button, ...styles.buttonSecondary, padding: "4px 8px" }}
                          onClick={() => {
                            toast({
                              title: "Room Details",
                              description: `Viewing details for room ${room.number}`,
                            })
                          }}
                        >
                          <MoreHorizontal style={{ height: "16px", width: "16px" }} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )

  const renderMessages = () => (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: "600" }}>Customer Messages</h2>
        <div style={{ display: "flex", gap: "8px" }}>
          <button
            style={{ ...styles.button, ...styles.buttonSecondary, display: "flex", alignItems: "center", gap: "4px" }}
          >
            <Filter style={{ height: "16px", width: "16px" }} />
            Filter
          </button>
          <button
            style={{ ...styles.button, ...styles.buttonPrimary, display: "flex", alignItems: "center", gap: "4px" }}
            onClick={() => {
              toast({
                title: "Mark All Read",
                description: "All messages marked as read",
              })
            }}
          >
            Mark All Read
          </button>
        </div>
      </div>

      <div style={styles.statsGrid}>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconBlue }}>
            <MessageSquare style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Total Messages</p>
            <h3 style={styles.statsNumber}>24</h3>
            <p style={{ fontSize: "12px", color: "#6b7280" }}>This week</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, backgroundColor: "#dcfce7", color: "#16a34a" }}>
            <MessageSquare style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Replied</p>
            <h3 style={styles.statsNumber}>18</h3>
            <p style={{ fontSize: "12px", color: "#16a34a" }}>75% response rate</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconAmber }}>
            <MessageSquare style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Pending</p>
            <h3 style={styles.statsNumber}>6</h3>
            <p style={{ fontSize: "12px", color: "#f59e0b" }}>Awaiting response</p>
          </div>
        </div>
      </div>

      <div style={{ ...styles.card, marginBottom: "24px" }}>
        <div style={styles.cardHeader}>
          <h3 style={styles.cardTitle}>Recent Messages</h3>
        </div>
        <div style={styles.cardContent}>
          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            {[
              {
                name: "John Smith",
                room: "101",
                message:
                  "The air conditioning in my room is not working properly. Could you please send someone to fix it?",
                time: "2 hours ago",
                status: "Unread",
                priority: "High",
              },
              {
                name: "Sarah Johnson",
                room: "205",
                message: "Thank you for the excellent service during my stay. The staff was very helpful.",
                time: "4 hours ago",
                status: "Read",
                priority: "Low",
              },
              {
                name: "Mike Wilson",
                room: "310",
                message: "I would like to request extra towels and pillows for my room.",
                time: "6 hours ago",
                status: "Replied",
                priority: "Medium",
              },
              {
                name: "Emma Davis",
                room: "102",
                message: "The WiFi password is not working. Could you please provide the correct one?",
                time: "1 day ago",
                status: "Unread",
                priority: "Medium",
              },
            ].map((msg, index) => (
              <div
                key={index}
                style={{
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                  padding: "16px",
                  backgroundColor: msg.status === "Unread" ? "#f8fafc" : "white",
                }}
              >
                <div
                  style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: "8px" }}
                >
                  <div>
                    <h4 style={{ fontSize: "16px", fontWeight: "500", margin: "0" }}>{msg.name}</h4>
                    <p style={{ fontSize: "12px", color: "#6b7280", margin: "0" }}>
                      Room {msg.room} • {msg.time}
                    </p>
                  </div>
                  <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                    <span
                      style={{
                        ...styles.badge,
                        ...(msg.priority === "High"
                          ? { backgroundColor: "#fee2e2", color: "#dc2626" }
                          : msg.priority === "Medium"
                            ? styles.badgeWarning
                            : { backgroundColor: "#e5e7eb", color: "#374151" }),
                      }}
                    >
                      {msg.priority}
                    </span>
                    <span
                      style={{
                        ...styles.badge,
                        ...(msg.status === "Unread"
                          ? { backgroundColor: "#fee2e2", color: "#dc2626" }
                          : msg.status === "Replied"
                            ? styles.badgeSuccess
                            : { backgroundColor: "#e5e7eb", color: "#374151" }),
                      }}
                    >
                      {msg.status}
                    </span>
                  </div>
                </div>
                <p style={{ fontSize: "14px", color: "#374151", margin: "0 0 12px 0" }}>{msg.message}</p>
                <div style={{ display: "flex", gap: "8px" }}>
                  <button
                    style={{ ...styles.button, ...styles.buttonPrimary, padding: "4px 12px", fontSize: "12px" }}
                    onClick={() => {
                      toast({
                        title: "Reply Sent",
                        description: `Reply sent to ${msg.name}`,
                      })
                    }}
                  >
                    Reply
                  </button>
                  <button
                    style={{ ...styles.button, ...styles.buttonSecondary, padding: "4px 12px", fontSize: "12px" }}
                    onClick={() => {
                      toast({
                        title: "Message Marked",
                        description: "Message marked as read",
                      })
                    }}
                  >
                    Mark Read
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )

  const renderCustomerReport = () => (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: "600" }}>Customer Reports</h2>
        <div style={{ display: "flex", gap: "8px" }}>
          <button
            style={{ ...styles.button, ...styles.buttonSecondary, display: "flex", alignItems: "center", gap: "4px" }}
          >
            <Download style={{ height: "16px", width: "16px" }} />
            Export Report
          </button>
          <button
            style={{ ...styles.button, ...styles.buttonPrimary, display: "flex", alignItems: "center", gap: "4px" }}
            onClick={() => {
              toast({
                title: "Generate Report",
                description: "New report generation started",
              })
            }}
          >
            <Plus style={{ height: "16px", width: "16px" }} />
            Generate Report
          </button>
        </div>
      </div>

      <div style={styles.statsGrid}>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconBlue }}>
            <Star style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Average Rating</p>
            <h3 style={styles.statsNumber}>4.5</h3>
            <p style={{ fontSize: "12px", color: "#16a34a" }}>+0.3 from last month</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, backgroundColor: "#dcfce7", color: "#16a34a" }}>
            <MessageSquare style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Total Reviews</p>
            <h3 style={styles.statsNumber}>156</h3>
            <p style={{ fontSize: "12px", color: "#16a34a" }}>This month</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconAmber }}>
            <Award style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Satisfaction Rate</p>
            <h3 style={styles.statsNumber}>92%</h3>
            <p style={{ fontSize: "12px", color: "#16a34a" }}>+5% improvement</p>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "24px", marginBottom: "24px" }}>
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <h3 style={styles.cardTitle}>Recent Reviews</h3>
          </div>
          <div style={styles.cardContent}>
            <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              {[
                {
                  name: "John Smith",
                  rating: 5,
                  comment: "Excellent service and clean rooms. Staff was very helpful throughout my stay.",
                  date: "2 days ago",
                },
                {
                  name: "Sarah Johnson",
                  rating: 4,
                  comment: "Good location and comfortable rooms. Breakfast could be improved.",
                  date: "3 days ago",
                },
                {
                  name: "Mike Wilson",
                  rating: 5,
                  comment: "Outstanding experience! Will definitely come back.",
                  date: "5 days ago",
                },
              ].map((review, index) => (
                <div key={index} style={{ borderBottom: "1px solid #e5e7eb", paddingBottom: "12px" }}>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      marginBottom: "8px",
                    }}
                  >
                    <h4 style={{ fontSize: "14px", fontWeight: "500", margin: "0" }}>{review.name}</h4>
                    <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          style={{
                            height: "12px",
                            width: "12px",
                            fill: i < review.rating ? "#f59e0b" : "#e5e7eb",
                            color: i < review.rating ? "#f59e0b" : "#e5e7eb",
                          }}
                        />
                      ))}
                      <span style={{ fontSize: "12px", color: "#6b7280", marginLeft: "4px" }}>{review.date}</span>
                    </div>
                  </div>
                  <p style={{ fontSize: "12px", color: "#374151", margin: "0" }}>{review.comment}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <h3 style={styles.cardTitle}>Rating Distribution</h3>
          </div>
          <div style={styles.cardContent}>
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              {[
                { stars: 5, count: 89, percentage: 57 },
                { stars: 4, count: 45, percentage: 29 },
                { stars: 3, count: 15, percentage: 10 },
                { stars: 2, count: 5, percentage: 3 },
                { stars: 1, count: 2, percentage: 1 },
              ].map((item, index) => (
                <div key={index} style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "4px", minWidth: "60px" }}>
                    <span style={{ fontSize: "14px" }}>{item.stars}</span>
                    <Star style={{ height: "12px", width: "12px", fill: "#f59e0b", color: "#f59e0b" }} />
                  </div>
                  <div
                    style={{
                      flex: "1",
                      backgroundColor: "#e5e7eb",
                      height: "8px",
                      borderRadius: "4px",
                      overflow: "hidden",
                    }}
                  >
                    <div
                      style={{
                        width: `${item.percentage}%`,
                        height: "100%",
                        backgroundColor: "#f59e0b",
                        borderRadius: "4px",
                      }}
                    ></div>
                  </div>
                  <span style={{ fontSize: "12px", color: "#6b7280", minWidth: "40px" }}>{item.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  const renderBillingSystem = () => (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: "600" }}>Billing System</h2>
        <div style={{ display: "flex", gap: "8px" }}>
          <button
            style={{ ...styles.button, ...styles.buttonSecondary, display: "flex", alignItems: "center", gap: "4px" }}
          >
            <Filter style={{ height: "16px", width: "16px" }} />
            Filter
          </button>
          <button
            style={{ ...styles.button, ...styles.buttonSecondary, display: "flex", alignItems: "center", gap: "4px" }}
          >
            <Download style={{ height: "16px", width: "16px" }} />
            Export
          </button>
          <button
            style={{ ...styles.button, ...styles.buttonPrimary, display: "flex", alignItems: "center", gap: "4px" }}
            onClick={() => {
              toast({
                title: "New Invoice",
                description: "Invoice creation form would open here",
              })
            }}
          >
            <Plus style={{ height: "16px", width: "16px" }} />
            New Invoice
          </button>
        </div>
      </div>

      <div style={styles.statsGrid}>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconBlue }}>
            <CreditCard style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Total Revenue</p>
            <h3 style={styles.statsNumber}>Rs.125,000</h3>
            <p style={{ fontSize: "12px", color: "#16a34a" }}>+12% from last month</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, backgroundColor: "#dcfce7", color: "#16a34a" }}>
            <DollarSign style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Paid Invoices</p>
            <h3 style={styles.statsNumber}>Rs.98,500</h3>
            <p style={{ fontSize: "12px", color: "#16a34a" }}>78% of total</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconAmber }}>
            <Clock style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Pending Payments</p>
            <h3 style={styles.statsNumber}>Rs.26,500</h3>
            <p style={{ fontSize: "12px", color: "#f59e0b" }}>22% of total</p>
          </div>
        </div>
      </div>

      <div style={{ ...styles.card, marginBottom: "24px" }}>
        <div style={styles.cardHeader}>
          <h3 style={styles.cardTitle}>Recent Invoices</h3>
        </div>
        <div style={styles.cardContent}>
          <div style={{ overflowX: "auto" }}>
            <table style={styles.table}>
              <thead style={styles.tableHeader}>
                <tr>
                  <th style={styles.tableHeaderCell}>Invoice ID</th>
                  <th style={styles.tableHeaderCell}>Guest</th>
                  <th style={styles.tableHeaderCell}>Date</th>
                  <th style={styles.tableHeaderCell}>Amount</th>
                  <th style={styles.tableHeaderCell}>Status</th>
                  <th style={{ ...styles.tableHeaderCell, textAlign: "right" }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((invoice) => (
                  <tr key={invoice.id} style={styles.tableRow}>
                    <td style={{ ...styles.tableCell, fontWeight: "500" }}>{invoice.id}</td>
                    <td style={styles.tableCell}>{invoice.guest}</td>
                    <td style={styles.tableCell}>{invoice.date}</td>
                    <td style={styles.tableCell}>{invoice.amount}</td>
                    <td style={styles.tableCell}>
                      <span
                        style={{
                          ...styles.badge,
                          ...(invoice.status === "Paid" ? styles.badgeSuccess : styles.badgeWarning),
                        }}
                      >
                        {invoice.status}
                      </span>
                    </td>
                    <td style={{ ...styles.tableCell, textAlign: "right" }}>
                      <button
                        style={{ ...styles.button, ...styles.buttonSecondary, padding: "4px 8px" }}
                        onClick={() => {
                          toast({
                            title: "Invoice actions",
                            description: `Actions for invoice ${invoice.id}`,
                          })
                        }}
                      >
                        <MoreHorizontal style={{ height: "16px", width: "16px" }} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )

  const renderService = () => (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: "600" }}>Service Management</h2>
        <div style={{ display: "flex", gap: "8px" }}>
          <button
            style={{ ...styles.button, ...styles.buttonSecondary, display: "flex", alignItems: "center", gap: "4px" }}
          >
            <Filter style={{ height: "16px", width: "16px" }} />
            Filter
          </button>
          <button
            style={{ ...styles.button, ...styles.buttonPrimary, display: "flex", alignItems: "center", gap: "4px" }}
            onClick={() => {
              toast({
                title: "New Service Request",
                description: "Service request form would open here",
              })
            }}
          >
            <Plus style={{ height: "16px", width: "16px" }} />
            New Service
          </button>
        </div>
      </div>

      <div style={styles.statsGrid}>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconBlue }}>
            <Utensils style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Food Services</p>
            <h3 style={styles.statsNumber}>28</h3>
            <p style={{ fontSize: "12px", color: "#16a34a" }}>Active orders</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, backgroundColor: "#dcfce7", color: "#16a34a" }}>
            <Home style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Housekeeping</p>
            <h3 style={styles.statsNumber}>15</h3>
            <p style={{ fontSize: "12px", color: "#16a34a" }}>Scheduled today</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, ...styles.statsIconAmber }}>
            <Award style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Maintenance</p>
            <h3 style={styles.statsNumber}>7</h3>
            <p style={{ fontSize: "12px", color: "#f59e0b" }}>Pending requests</p>
          </div>
        </div>
        <div style={styles.statsCard}>
          <div style={{ ...styles.statsIcon, backgroundColor: "#e0e7ff", color: "#6366f1" }}>
            <MessageSquare style={{ height: "24px", width: "24px" }} />
          </div>
          <div>
            <p style={styles.statsLabel}>Concierge</p>
            <h3 style={styles.statsNumber}>12</h3>
            <p style={{ fontSize: "12px", color: "#6366f1" }}>Guest requests</p>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "24px", marginBottom: "24px" }}>
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <h3 style={styles.cardTitle}>Active Service Requests</h3>
          </div>
          <div style={styles.cardContent}>
            <div style={{ overflowX: "auto" }}>
              <table style={styles.table}>
                <thead style={styles.tableHeader}>
                  <tr>
                    <th style={styles.tableHeaderCell}>Service Type</th>
                    <th style={styles.tableHeaderCell}>Guest</th>
                    <th style={styles.tableHeaderCell}>Room</th>
                    <th style={styles.tableHeaderCell}>Priority</th>
                    <th style={styles.tableHeaderCell}>Status</th>
                    <th style={styles.tableHeaderCell}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { type: "Room Service", guest: "John Smith", room: "101", priority: "High", status: "In Progress" },
                    {
                      type: "Housekeeping",
                      guest: "Sarah Johnson",
                      room: "205",
                      priority: "Medium",
                      status: "Pending",
                    },
                    { type: "Maintenance", guest: "Mike Wilson", room: "310", priority: "High", status: "Assigned" },
                    { type: "Concierge", guest: "Emma Davis", room: "102", priority: "Low", status: "Completed" },
                  ].map((service, index) => (
                    <tr key={index} style={styles.tableRow}>
                      <td style={{ ...styles.tableCell, fontWeight: "500" }}>{service.type}</td>
                      <td style={styles.tableCell}>{service.guest}</td>
                      <td style={styles.tableCell}>{service.room}</td>
                      <td style={styles.tableCell}>
                        <span
                          style={{
                            ...styles.badge,
                            ...(service.priority === "High"
                              ? { backgroundColor: "#fee2e2", color: "#dc2626" }
                              : service.priority === "Medium"
                                ? styles.badgeWarning
                                : { backgroundColor: "#e5e7eb", color: "#374151" }),
                          }}
                        >
                          {service.priority}
                        </span>
                      </td>
                      <td style={styles.tableCell}>
                        <span
                          style={{
                            ...styles.badge,
                            ...(service.status === "Completed"
                              ? styles.badgeSuccess
                              : service.status === "In Progress"
                                ? { backgroundColor: "#e0e7ff", color: "#6366f1" }
                                : styles.badgeWarning),
                          }}
                        >
                          {service.status}
                        </span>
                      </td>
                      <td style={styles.tableCell}>
                        <button
                          style={{ ...styles.button, ...styles.buttonSecondary, padding: "4px 8px" }}
                          onClick={() => {
                            toast({
                              title: "Service Update",
                              description: `Updating ${service.type} for ${service.guest}`,
                            })
                          }}
                        >
                          <MoreHorizontal style={{ height: "16px", width: "16px" }} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <h3 style={styles.cardTitle}>Service Distribution</h3>
          </div>
          <div style={styles.cardContent}>
            <div style={{ height: "250px" }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={[
                      { name: "Room Service", value: 35 },
                      { name: "Housekeeping", value: 25 },
                      { name: "Maintenance", value: 20 },
                      { name: "Concierge", value: 20 },
                    ]}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {[
                      { name: "Room Service", value: 35 },
                      { name: "Housekeeping", value: 25 },
                      { name: "Maintenance", value: 20 },
                      { name: "Concierge", value: 20 },
                    ].map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div
              style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "16px", marginTop: "16px" }}
            >
              {[
                { name: "Room Service", value: 35 },
                { name: "Housekeeping", value: 25 },
                { name: "Maintenance", value: 20 },
                { name: "Concierge", value: 20 },
              ].map((entry, index) => (
                <div key={index} style={{ display: "flex", alignItems: "center" }}>
                  <div
                    style={{
                      width: "12px",
                      height: "12px",
                      borderRadius: "50%",
                      marginRight: "4px",
                      backgroundColor: COLORS[index % COLORS.length],
                    }}
                  ></div>
                  <span style={{ fontSize: "12px" }}>
                    {entry.name}: {entry.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  return (
    <div style={styles.container}>
      {/* Mobile Sidebar Toggle */}
      {isMobile && (
        <button
          style={{
            ...styles.mobileToggle,
            display: sidebarOpen ? "none" : "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
          onClick={() => setSidebarOpen(true)}
        >
          <Menu style={{ height: "24px", width: "24px" }} />
        </button>
      )}

      {/* Sidebar */}
      <div
        style={{
          ...styles.sidebar,
          ...(isMobile
            ? {
                ...styles.sidebarMobile,
                ...(sidebarOpen ? {} : styles.sidebarMobileHidden),
              }
            : {}),
        }}
      >
        {isMobile && (
          <div style={{ display: "flex", justifyContent: "flex-end", padding: "16px" }}>
            <button
              style={{ ...styles.button, ...styles.buttonSecondary, padding: "4px 8px" }}
              onClick={() => setSidebarOpen(false)}
            >
              <ChevronLeft style={{ height: "24px", width: "24px" }} />
            </button>
          </div>
        )}
        <div style={styles.sidebarHeader}>
          <h1 style={styles.logo}>Traexco</h1>
        </div>
        <div style={styles.nav}>
          <nav style={styles.navList}>
            <button
              onClick={() => setActiveSection("dashboard")}
              style={{
                ...styles.navButton,
                ...(activeSection === "dashboard" ? styles.navButtonActive : styles.navButtonInactive),
              }}
            >
              <BarChart style={styles.navIcon} />
              Dashboard
            </button>
            <button
              onClick={() => setActiveSection("check-in-out")}
              style={{
                ...styles.navButton,
                ...(activeSection === "check-in-out" ? styles.navButtonActive : styles.navButtonInactive),
              }}
            >
              <CalendarIcon style={styles.navIcon} />
              Check In-Out
            </button>
            <button
              onClick={() => setActiveSection("rooms")}
              style={{
                ...styles.navButton,
                ...(activeSection === "rooms" ? styles.navButtonActive : styles.navButtonInactive),
              }}
            >
              <Home style={styles.navIcon} />
              Rooms
            </button>
            <button
              onClick={() => setActiveSection("messages")}
              style={{
                ...styles.navButton,
                ...(activeSection === "messages" ? styles.navButtonActive : styles.navButtonInactive),
              }}
            >
              <MessageSquare style={styles.navIcon} />
              Messages
            </button>
            <button
              onClick={() => setActiveSection("customer-report")}
              style={{
                ...styles.navButton,
                ...(activeSection === "customer-report" ? styles.navButtonActive : styles.navButtonInactive),
              }}
            >
              <Star style={styles.navIcon} />
              Customer Report
            </button>
            <button
              onClick={() => setActiveSection("billing")}
              style={{
                ...styles.navButton,
                ...(activeSection === "billing" ? styles.navButtonActive : styles.navButtonInactive),
              }}
            >
              <CreditCard style={styles.navIcon} />
              Billing System
            </button>
            <button
              onClick={() => setActiveSection("service")}
              style={{
                ...styles.navButton,
                ...(activeSection === "service" ? styles.navButtonActive : styles.navButtonInactive),
              }}
            >
              <Utensils style={styles.navIcon} />
              Service
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <header style={styles.header}>
          <div style={{ display: "flex", alignItems: "center" }}>
            {isMobile && (
              <button
                style={{ ...styles.button, ...styles.buttonSecondary, marginRight: "8px", padding: "4px 8px" }}
                onClick={() => setSidebarOpen(true)}
              >
                <Menu style={{ height: "20px", width: "20px" }} />
              </button>
            )}
            <h1 style={styles.headerTitle}>
              {activeSection === "dashboard"
                ? "Dashboard"
                : activeSection === "check-in-out"
                  ? "Check In-Out"
                  : activeSection === "rooms"
                    ? "Rooms"
                    : activeSection === "messages"
                      ? "Messages"
                      : activeSection === "customer-report"
                        ? "Customer Report"
                        : activeSection === "billing"
                          ? "Billing System"
                          : activeSection === "service"
                            ? "Service Management"
                            : "Dashboard"}
            </h1>
          </div>
          <div style={styles.headerActions}>
            <button
              style={{
                ...styles.button,
                ...styles.buttonSecondary,
                display: "flex",
                alignItems: "center",
                gap: "8px",
                padding: "8px 12px",
              }}
            >
              <img
                src="/placeholder.svg?height=24&width=24"
                width={24}
                height={24}
                alt="Hotel"
                style={{ borderRadius: "4px" }}
              />
              <span style={{ display: isMobile ? "none" : "inline" }}>Hotel Hilton Garden Inn</span>
              <ChevronDown style={{ height: "16px", width: "16px" }} />
            </button>

            <button style={{ ...styles.button, ...styles.buttonSecondary, position: "relative", padding: "8px" }}>
              <Bell style={{ height: "20px", width: "20px" }} />
              <span
                style={{
                  position: "absolute",
                  top: "0",
                  right: "0",
                  height: "8px",
                  width: "8px",
                  backgroundColor: "#ef4444",
                  borderRadius: "50%",
                }}
              ></span>
            </button>

            <button style={{ ...styles.button, ...styles.buttonSecondary, borderRadius: "50%", padding: "4px" }}>
              <img
                src="/placeholder.svg?height=32&width=32"
                alt="User"
                style={{ width: "32px", height: "32px", borderRadius: "50%" }}
              />
            </button>
          </div>
        </header>

        {/* Main Content */}
        <main style={styles.main}>
          {activeSection === "dashboard" && renderDashboard()}
          {activeSection === "check-in-out" && renderCheckInOut()}
          {activeSection === "rooms" && renderRooms()}
          {activeSection === "messages" && renderMessages()}
          {activeSection === "customer-report" && renderCustomerReport()}
          {activeSection === "billing" && renderBillingSystem()}
          {activeSection === "service" && renderService()}
        </main>
      </div>
    </div>
  )
}
