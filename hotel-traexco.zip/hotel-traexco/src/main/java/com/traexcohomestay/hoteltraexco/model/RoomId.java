package com.traexcohomestay.hoteltraexco.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.Hibernate;

import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Embeddable
public class RoomId implements Serializable {
    private static final long serialVersionUID = -3207978839167396026L;
    @Column(name = "homestay_id", nullable = false)
    private Integer homestayId;

    @Column(name = "room_number", nullable = false, length = 10)
    private String roomNumber;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        RoomId entity = (RoomId) o;
        return Objects.equals(this.roomNumber, entity.roomNumber) &&
                Objects.equals(this.homestayId, entity.homestayId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(roomNumber, homestayId);
    }

}