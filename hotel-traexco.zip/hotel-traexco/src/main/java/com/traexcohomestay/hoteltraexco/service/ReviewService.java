package com.traexcohomestay.hoteltraexco.service;

import com.traexcohomestay.hoteltraexco.dto.ReviewRoomDTO;
import java.util.List;

public interface ReviewService {
    List<ReviewRoomDTO> getReviewsByRoom(Integer homestayId, String roomNumber);
}