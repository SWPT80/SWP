package com.traexcohomestay.hoteltraexco.dto;

import lombok.Data;

@Data
public class HomestayImageDTO {
    private String imageUrl;
    private String description;
}
    