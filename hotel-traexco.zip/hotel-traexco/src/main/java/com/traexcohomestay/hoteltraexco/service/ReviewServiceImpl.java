package com.traexcohomestay.hoteltraexco.service;

import com.traexcohomestay.hoteltraexco.dto.ReviewRoomDTO;
import com.traexcohomestay.hoteltraexco.model.Review;
import com.traexcohomestay.hoteltraexco.model.ReviewRoom;
import com.traexcohomestay.hoteltraexco.repository.ReviewRoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ReviewServiceImpl implements ReviewService {

    @Autowired
    private ReviewRoomRepository reviewRoomRepository;

    @Override
    @Transactional(readOnly = true)
    public List<ReviewRoomDTO> getReviewsByRoom(Integer homestayId, String roomNumber) {
        List<ReviewRoom> reviewRooms = reviewRoomRepository.findByRooms_Id_HomestayIdAndRooms_Id_RoomNumber(homestayId, roomNumber);
        return reviewRooms.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    private ReviewRoomDTO convertToDTO(ReviewRoom reviewRoom) {
        ReviewRoomDTO dto = new ReviewRoomDTO();
        Review review = reviewRoom.getReview();
        dto.setReviewId(review.getId());
        dto.setUserName(review.getUser().getFullName());
        dto.setRating(reviewRoom.getRating());
        dto.setComment(reviewRoom.getComment());
        dto.setCreatedAt(review.getCreatedAt());
        return dto;
    }
}