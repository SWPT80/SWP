package com.traexcohomestay.hoteltraexco.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExperienceImageDTO {
    private String imageUrl;
    private Boolean status;
}