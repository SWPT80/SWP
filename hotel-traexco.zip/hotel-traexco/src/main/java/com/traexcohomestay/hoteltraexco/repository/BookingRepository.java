package com.traexcohomestay.hoteltraexco.repository;

import com.traexcohomestay.hoteltraexco.model.Booking;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer> {
    @EntityGraph(attributePaths = {"user", "rooms", "rooms.homestay", "bookingServices", "bookingServices.service", "bookingServices.service.serviceType"})
    Optional<Booking> findById(Integer id);

    @EntityGraph(attributePaths = {"user", "rooms", "rooms.homestay", "bookingServices", "bookingServices.service", "bookingServices.service.serviceType"})
    Optional<Booking> findTopByUserIdOrderByCreatedAtDesc(Integer userId);
}