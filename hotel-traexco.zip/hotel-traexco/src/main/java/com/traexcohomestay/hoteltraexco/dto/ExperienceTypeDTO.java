package com.traexcohomestay.hoteltraexco.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExperienceTypeDTO {
    private Integer id;
    private String experienceName;
    private String description;
    private String iconClass;
}