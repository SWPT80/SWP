package com.traexcohomestay.hoteltraexco.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
public class BookingDTO {
    private Integer userId;
    private Integer homestayId;
    private String roomNumber;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate checkInDate;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate checkOutDate;
    private Integer adults;
    private Integer children;
    private Integer totalPeople;
    private BigDecimal totalAmount;
}