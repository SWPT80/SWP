package com.traexcohomestay.hoteltraexco.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ServiceImageDTO {
    private String imageUrl;
    private String description;
    private Boolean status;
}