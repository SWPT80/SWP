package com.traexcohomestay.hoteltraexco.controller;

import com.traexcohomestay.hoteltraexco.dto.ReviewRoomDTO;
import com.traexcohomestay.hoteltraexco.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/reviews/room")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @GetMapping("/{homestayId}/{roomNumber}")
    public ResponseEntity<List<ReviewRoomDTO>> getReviewsByRoom(
            @PathVariable Integer homestayId,
            @PathVariable String roomNumber) {
        return ResponseEntity.ok(reviewService.getReviewsByRoom(homestayId, roomNumber));
    }
}