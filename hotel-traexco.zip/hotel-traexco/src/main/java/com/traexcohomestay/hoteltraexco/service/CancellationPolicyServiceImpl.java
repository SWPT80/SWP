package com.traexcohomestay.hoteltraexco.service;

import com.traexcohomestay.hoteltraexco.dto.CancellationPolicyDTO;
import com.traexcohomestay.hoteltraexco.model.CancellationPolicy;
import com.traexcohomestay.hoteltraexco.repository.CancellationPolicyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class CancellationPolicyServiceImpl implements CancellationPolicyService {

    @Autowired
    private CancellationPolicyRepository cancellationPolicyRepository;

    @Override
    @Transactional(readOnly = true)
    public List<CancellationPolicyDTO> getPoliciesByHomestayId(Integer homestayId) {
        List<CancellationPolicy> policies = cancellationPolicyRepository.findByHomestay_HomestayId(homestayId);
        return policies.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    private CancellationPolicyDTO convertToDTO(CancellationPolicy policy) {
        CancellationPolicyDTO dto = new CancellationPolicyDTO();
        dto.setPolicyId(policy.getId());
        dto.setName(policy.getName());
        dto.setDescription(policy.getDescription());
        dto.setRefundPercentage(policy.getRefundPercentage());
        dto.setDaysBeforeCheckin(policy.getDaysBeforeCheckin());
        return dto;
    }
}