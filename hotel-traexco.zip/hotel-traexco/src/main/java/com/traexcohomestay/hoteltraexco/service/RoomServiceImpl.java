package com.traexcohomestay.hoteltraexco.service;

import com.traexcohomestay.hoteltraexco.dto.*;
import com.traexcohomestay.hoteltraexco.exception.ResourceNotFoundException;
import com.traexcohomestay.hoteltraexco.model.*;
import com.traexcohomestay.hoteltraexco.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class RoomServiceImpl implements RoomService {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private HomestayRepository homestayRepository;

    @Autowired
    private RoomImageRepository roomImageRepository;

    @Autowired
    private AmenityRepository amenityRepository;

    @Override
    @Transactional(readOnly = true)
    public RoomDetailsDTO getRoomDetails(Integer homestayId, String roomNumber) {
        Room room = roomRepository.findById(new RoomId(homestayId, roomNumber))
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with homestayId: " + homestayId + " and roomNumber: " + roomNumber));

        Homestay homestay = homestayRepository.findById(homestayId)
                .orElseThrow(() -> new ResourceNotFoundException("Homestay not found with id: " + homestayId));

        List<RoomImage> images = roomImageRepository.findByRooms_Id_HomestayIdAndRooms_Id_RoomNumber(homestayId, roomNumber);
        List<Amenity> amenities = amenityRepository.findByHomestay_HomestayId(homestayId);

        return convertToDTO(room, homestay, images, amenities);
    }

    @Override
    public List<RoomDTO> getRoomsByHomestayId(Integer homestayId) {
        List<Room> rooms = roomRepository.findByHomestay_HomestayId(homestayId);
        return rooms.stream().map(this::convertToRoomDTO).collect(Collectors.toList());
    }

    private RoomDTO convertToRoomDTO(Room room) {
        RoomDTO dto = new RoomDTO();
        dto.setHomestayId(room.getId().getHomestayId());
        dto.setRoomNumber(room.getId().getRoomNumber());
        dto.setType(room.getType());
        dto.setPrice(room.getPrice());
        dto.setCapacity(room.getCapacity());
        dto.setRating(room.getRating());
        dto.setStatus(room.getStatus());
        return dto;
    }

    private RoomDetailsDTO convertToDTO(Room room, Homestay homestay, List<RoomImage> images, List<Amenity> amenities) {
        RoomDetailsDTO dto = new RoomDetailsDTO();

        // Room
        RoomDTO roomDTO = new RoomDTO();
        roomDTO.setHomestayId(room.getId().getHomestayId());
        roomDTO.setRoomNumber(room.getId().getRoomNumber());
        roomDTO.setType(room.getType());
        roomDTO.setPrice(room.getPrice());
        roomDTO.setCapacity(room.getCapacity());
        roomDTO.setRating(room.getRating());
        roomDTO.setStatus(room.getStatus());
        dto.setRoom(roomDTO);

        // Homestay
        HomestayDTO homestayDTO = new HomestayDTO();
        homestayDTO.setId(homestay.getHomestayId());
        homestayDTO.setHomestayName(homestay.getHomestayName());
        homestayDTO.setAddress(homestay.getAddress());
        homestayDTO.setLocation(homestay.getLocation());
        homestayDTO.setDescription(homestay.getDescription());
        homestayDTO.setHostId(homestay.getHostId());
        homestayDTO.setStatus(homestay.getStatus());
        dto.setHomestay(homestayDTO);

        // Images
        List<RoomImageDTO> imageDTOs = images.stream().map(image -> {
            RoomImageDTO imgDTO = new RoomImageDTO();
            imgDTO.setImageUrl(image.getImageUrl());
            imgDTO.setDescription(image.getDescription());
            return imgDTO;
        }).collect(Collectors.toList());
        dto.setImages(imageDTOs);

        // Amenities
        List<AmenityDTO> amenityDTOs = amenities.stream().map(amenity -> {
            AmenityDTO amenityDTO = new AmenityDTO();
            amenityDTO.setTypeId(amenity.getType().getId());
            amenityDTO.setTypeName(amenity.getType().getTypeName());
            amenityDTO.setIconClass(amenity.getType().getAmenityIcon().getIconClass());
            return amenityDTO;
        }).collect(Collectors.toList());
        dto.setAmenities(amenityDTOs);

        return dto;
    }
}