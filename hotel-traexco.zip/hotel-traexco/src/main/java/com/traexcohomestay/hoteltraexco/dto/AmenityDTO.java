package com.traexcohomestay.hoteltraexco.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public  class AmenityDTO {
    private Integer typeId;
    private String typeName;
    private String iconClass;
}
