package com.traexcohomestay.hoteltraexco.controller;

import com.traexcohomestay.hoteltraexco.dto.CancellationPolicyDTO;
import com.traexcohomestay.hoteltraexco.service.CancellationPolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/cancellation-policies")
public class CancellationPolicyController {

    @Autowired
    private CancellationPolicyService cancellationPolicyService;

    @GetMapping("/homestay/{homestayId}")
    public ResponseEntity<List<CancellationPolicyDTO>> getPoliciesByHomestayId(@PathVariable Integer homestayId) {
        return ResponseEntity.ok(cancellationPolicyService.getPoliciesByHomestayId(homestayId));
    }
}