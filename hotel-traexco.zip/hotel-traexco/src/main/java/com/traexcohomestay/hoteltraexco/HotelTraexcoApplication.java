package com.traexcohomestay.hoteltraexco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class HotelTraexcoApplication {

    public static void main(String[] args) {
        SpringApplication.run(HotelTraexcoApplication.class, args);
    }

}
