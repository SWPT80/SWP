package com.traexcohomestay.hoteltraexco.service;

import com.traexcohomestay.hoteltraexco.dto.BookingDTO;
import com.traexcohomestay.hoteltraexco.dto.ServiceDTO;
import com.traexcohomestay.hoteltraexco.dto.ServiceTypeDTO;
import com.traexcohomestay.hoteltraexco.exception.ResourceNotFoundException;
import com.traexcohomestay.hoteltraexco.model.*;
import com.traexcohomestay.hoteltraexco.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class BookingServiceServiceImpl implements BookingServiceService {
    private static final Logger logger = LoggerFactory.getLogger(BookingServiceServiceImpl.class);

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final RoomRepository roomRepository;
    private final ServiceRepository serviceRepository;
    private final BookingServiceRepository bookingServiceRepository;

    @Autowired
    public BookingServiceServiceImpl(
            BookingRepository bookingRepository,
            UserRepository userRepository,
            RoomRepository roomRepository,
            ServiceRepository serviceRepository,
            BookingServiceRepository bookingServiceRepository) {
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
        this.roomRepository = roomRepository;
        this.serviceRepository = serviceRepository;
        this.bookingServiceRepository = bookingServiceRepository;
    }

    @Override
    public BookingDTO createBooking(BookingDTO bookingDTO) {
        logger.info("Received booking request: {}", bookingDTO);
        if (bookingDTO == null) {
            logger.error("BookingDTO is null");
            throw new IllegalArgumentException("BookingDTO is null");
        }
        if (bookingDTO.getUserId() == null || bookingDTO.getHomestayId() == null ||
                bookingDTO.getRoomNumber() == null || bookingDTO.getCheckInDate() == null ||
                bookingDTO.getCheckOutDate() == null || bookingDTO.getAdults() == null ||
                bookingDTO.getChildren() == null || bookingDTO.getTotalPeople() == null ||
                bookingDTO.getTotalAmount() == null) {
            logger.error("Missing required fields in bookingDTO: {}", bookingDTO);
            throw new IllegalArgumentException("All required fields must be provided");
        }

        User user = userRepository.findById(bookingDTO.getUserId())
                .orElseThrow(() -> {
                    logger.error("User not found with id: {}", bookingDTO.getUserId());
                    return new ResourceNotFoundException("User not found with id: " + bookingDTO.getUserId());
                });
        logger.info("Found user: {}", user);

        RoomId roomId = new RoomId(bookingDTO.getHomestayId(), bookingDTO.getRoomNumber());
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> {
                    logger.error("Room not found with homestayId: {} and roomNumber: {}", bookingDTO.getHomestayId(), bookingDTO.getRoomNumber());
                    return new ResourceNotFoundException("Room not found with homestayId: " + bookingDTO.getHomestayId() + " and roomNumber: " + bookingDTO.getRoomNumber());
                });
        logger.info("Found room: {}", room);

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setRooms(room);
        booking.setCheckInDate(bookingDTO.getCheckInDate());
        booking.setCheckOutDate(bookingDTO.getCheckOutDate());
        booking.setAdults(bookingDTO.getAdults());
        booking.setChildren(bookingDTO.getChildren());
        booking.setTotalPeople(bookingDTO.getTotalPeople());
        booking.setTotalAmount(bookingDTO.getTotalAmount());
        booking.setStatus("PENDING");

        try {
            Booking savedBooking = bookingRepository.save(booking);
            logger.info("Saved booking ID: {}", savedBooking.getId());

            // Convert saved booking to DTO
            BookingDTO result = new BookingDTO();
            result.setId(savedBooking.getId());
            result.setUserId(savedBooking.getUser().getId());
            result.setHomestayId(savedBooking.getRooms().getId().getHomestayId());
            result.setRoomNumber(savedBooking.getRooms().getId().getRoomNumber());
            result.setCheckInDate(savedBooking.getCheckInDate());
            result.setCheckOutDate(savedBooking.getCheckOutDate());
            result.setAdults(savedBooking.getAdults());
            result.setChildren(savedBooking.getChildren());
            result.setTotalPeople(savedBooking.getTotalPeople());
            result.setTotalAmount(savedBooking.getTotalAmount());

            // Xử lý danh sách dịch vụ (quan trọng)
            List<String> serviceIds = bookingDTO.getServices() != null ? bookingDTO.getServices() : new ArrayList<>(); // Tránh null
            List<ServiceDTO> serviceDTOs = new ArrayList<>(); // Dùng để trả về thông tin đầy đủ

            if (!serviceIds.isEmpty()) {
                List<BookingService> bookingServices = serviceIds.stream()
                        .map(serviceId -> {
                            com.traexcohomestay.hoteltraexco.model.Service service = serviceRepository.findById(Integer.valueOf(serviceId))
                                    .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy dịch vụ với id: " + serviceId));

                            // Tạo đối tượng BookingService để lưu vào DB
                            BookingService bookingService = new BookingService();
                            bookingService.setId(new BookingServiceId(savedBooking.getId(), Integer.valueOf(serviceId)));
                            bookingService.setBooking(savedBooking);
                            bookingService.setService(service);
                            bookingService.setQuantity(1);

                            // Đồng thời build DTO để trả về
                            ServiceDTO serviceDTO = new ServiceDTO();
                            serviceDTO.setId(service.getId());
                            serviceDTO.setPrice(service.getPrice());
                            serviceDTO.setSpecialNotes(service.getSpecialNotes());
                            if (service.getServiceType() != null) {
                                ServiceTypeDTO typeDTO = new ServiceTypeDTO();
                                typeDTO.setServiceName(service.getServiceType().getServiceName());
                                serviceDTO.setServiceType(typeDTO);
                            }
                            serviceDTOs.add(serviceDTO);

                            return bookingService;
                        })
                        .collect(Collectors.toList());

                bookingServiceRepository.saveAll(bookingServices);
            }

            // Set danh sách dịch vụ đã xử lý vào kết quả
            List<String> serviceId = serviceDTOs.stream()
                    .map(serviceDTO -> String.valueOf(serviceDTO.getId()))
                    .collect(Collectors.toList());
            result.setServices(serviceId); // Trả về List<ServiceDTO> thay vì List<String>

            logger.info("Returning BookingDTO: {}", result);
            return result;
        } catch (Exception e) {
            logger.error("Error saving booking: {}", e.getMessage(), e);
            throw e;
        }
    }
}