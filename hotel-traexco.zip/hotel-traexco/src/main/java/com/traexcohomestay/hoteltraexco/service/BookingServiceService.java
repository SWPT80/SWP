package com.traexcohomestay.hoteltraexco.service;

import com.traexcohomestay.hoteltraexco.dto.BookingDTO;

public interface BookingServiceService {
    BookingDTO createBooking(BookingDTO bookingDTO);
}