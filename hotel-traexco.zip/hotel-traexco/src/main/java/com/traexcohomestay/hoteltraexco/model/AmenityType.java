package com.traexcohomestay.hoteltraexco.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Nationalized;

@Getter
@Setter
@Entity
public class AmenityType {
    @Id
    @Column(name = "type_id", nullable = false)
    private Integer id;

    @Nationalized
    @Column(name = "typeName", length = 100)
    private String typeName;

}