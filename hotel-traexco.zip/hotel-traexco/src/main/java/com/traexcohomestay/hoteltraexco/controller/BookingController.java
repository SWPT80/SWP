package com.traexcohomestay.hoteltraexco.controller;

import com.traexcohomestay.hoteltraexco.dto.BookingDTO;
import com.traexcohomestay.hoteltraexco.dto.ServiceDTO;
import com.traexcohomestay.hoteltraexco.dto.ServiceTypeDTO;
import com.traexcohomestay.hoteltraexco.exception.ResourceNotFoundException;
import com.traexcohomestay.hoteltraexco.model.Booking;
import com.traexcohomestay.hoteltraexco.model.BookingService;
import com.traexcohomestay.hoteltraexco.repository.BookingRepository;
import com.traexcohomestay.hoteltraexco.service.BookingServiceService;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private BookingServiceService bookingService;

    @GetMapping("/{id}")
    public ResponseEntity<BookingDTO> getBookingById(@PathVariable Integer id) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + id));

        // Fetch thêm dữ liệu liên quan
        Hibernate.initialize(booking.getBookingServices());
        if (booking.getBookingServices() != null) {
            booking.getBookingServices().forEach(bs -> {
                Hibernate.initialize(bs.getService());
                if (bs.getService() != null) {
                    Hibernate.initialize(bs.getService().getServiceType());
                }
            });
        }

        return ResponseEntity.ok(convertToDTO(booking));
    }

    @PostMapping
    public ResponseEntity<?> createBooking(@RequestBody BookingDTO bookingDTO) {
        try {
            BookingDTO createdBooking = bookingService.createBooking(bookingDTO);
            return ResponseEntity.ok(createdBooking);
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Lỗi khi tạo đặt phòng");
        }
    }

    @GetMapping("/user/{userId}/latest")
    public ResponseEntity<BookingDTO> getLatestBookingByUser(@PathVariable Integer userId) {
        Booking booking = bookingRepository.findTopByUserIdOrderByCreatedAtDesc(userId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy đặt phòng nào cho người dùng này."));
        BookingDTO bookingDTO = convertToDTO(booking);
        return ResponseEntity.ok(bookingDTO);
    }

    private BookingDTO convertToDTO(Booking booking) {
        BookingDTO dto = new BookingDTO();
        dto.setId(booking.getId());
        dto.setUserId(booking.getUser().getId());
        dto.setHomestayId(booking.getRooms().getId().getHomestayId());
        dto.setHomestayName(booking.getRooms().getHomestay().getHomestayName());
        dto.setRoomNumber(booking.getRooms().getId().getRoomNumber());
        dto.setCheckInDate(booking.getCheckInDate());
        dto.setCheckOutDate(booking.getCheckOutDate());
        dto.setAdults(booking.getAdults());
        dto.setChildren(booking.getChildren());
        dto.setTotalPeople(booking.getTotalPeople());
        dto.setTotalAmount(booking.getTotalAmount());
        dto.setStatus(booking.getStatus()); // Thêm trạng thái booking

        if (booking.getBookingServices() != null && !booking.getBookingServices().isEmpty()) {
            // Tạo danh sách ServiceDTO đầy đủ thông tin
            List<ServiceDTO> serviceDTOs = booking.getBookingServices().stream()
                    .map(bs -> {
                        ServiceDTO serviceDTO = new ServiceDTO();
                        serviceDTO.setId(bs.getService().getId());
                        serviceDTO.setPrice(bs.getService().getPrice());
                        serviceDTO.setSpecialNotes(bs.getService().getSpecialNotes());

                        if (bs.getService().getServiceType() != null) {
                            ServiceTypeDTO typeDTO = new ServiceTypeDTO();
                            typeDTO.setServiceName(bs.getService().getServiceType().getServiceName());
                            serviceDTO.setServiceType(typeDTO);
                        }
                        return serviceDTO;
                    })
                    .collect(Collectors.toList());

            // Set cả danh sách dịch vụ đầy đủ thông tin
            dto.setServiceDetails(serviceDTOs); // Bạn cần thêm trường này trong BookingDTO

            // Set cả danh sách ID dịch vụ (nếu cần)
            List<String> serviceIds = serviceDTOs.stream()
                    .map(s -> String.valueOf(s.getId()))
                    .collect(Collectors.toList());
            dto.setServices(serviceIds);
        }

        return dto;
    }
}