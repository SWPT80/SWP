package com.traexcohomestay.hoteltraexco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelTraexcoApplicationTests {

    @Test
    void contextLoads() {
    }

}
